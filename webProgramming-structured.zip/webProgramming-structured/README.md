# advancedProgrammingTechniques

Εφαρμογή Tennis Club

Περιγραφή 

Εφαρμογή Tennis Club. 
Χρησιμοποιεί Node.js με CommonJS moduling και PostgreSQL database. 
Για installation θα πρέπει να δημιουργηθεί τοπικά database σύμφωνα με το αρχείο make_new_database.sql που περιλαμβάνεται στον φάκελο data. Θα πρέπει επίσης να δημιουργηθεί αρχείο .env με τα στοιχεία του database. Στη συνέχεια αρκεί ένα npm install και npm run watch για χρήση του προγράμματος. 

Περιεχόμενα αρχείου .env : 

//στοιχεια database 
PG_HOST= 
PG_PORT= 
PG_USER= 
PG_PASSWORD= 
PG_DATABASE= 

//στοιχεία session που επιλέγονται από το χρήστη
SESSION_SECRET = 
SESSION_NAME = 